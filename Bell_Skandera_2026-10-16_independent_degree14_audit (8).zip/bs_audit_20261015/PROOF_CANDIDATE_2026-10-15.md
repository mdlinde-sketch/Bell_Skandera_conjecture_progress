# Bell–Skandera conjecture in degrees at most 12: candidate computer-assisted proof

**15 October 2026, Brisbane. Status: UNREVIEWED RESEARCH PREPRINT / CANDIDATE PROOF.**

The argument below is a *proposed* finite-degree theorem. It uses Smyth's published theorem about totally positive algebraic integers, standard Newton–Maclaurin and Kruskal–Katona results, and two exact-integer computer certificates. It has not been refereed, independently mathematically reviewed, or established as novel. It does **not** resolve Bell–Skandera in all degrees.

## Statement

**Candidate theorem.** Let \(F(t)=1+u_1t+\cdots+u_dt^d\) have positive integer coefficients and only real zeros, with \(1\le d\le12\). Then \((1,u_1,\ldots,u_d)\) is the face vector of a simplicial complex.

The verification code `verify_through_12.py` completed, reporting no surviving configurations for each \(2\le d\le12\); an independently written direct-determinant audit `independent_residual_audit.py` also completed. The core argument and logical dependencies follow, so this is a *candidate computer-assisted proof*, not a claim of settled mathematical fact.

## 1. Finite adjacent-pair reduction

All real zeros of \(F\) are negative, since its coefficients are positive. Thus
\[
F(t)=\prod_{i=1}^d(1+\lambda_i t),\qquad \lambda_i>0,
\]
where the \(\lambda_i\) are totally positive algebraic integers: their monic integer polynomial is \(x^d-u_1x^{d-1}+u_2x^{d-2}-\cdots+(-1)^d u_d\).

Set \(C_j=\binom{d}{j}\), \(v_j=u_j/C_j\), \(v_0=1\). Newton's inequalities say \(v_j^2\ge v_{j-1}v_{j+1}\). Also \(v_d=u_d\ge1\), so log-concavity implies \(v_j\ge1\), hence \(u_j\ge C_j\).

Let \(K_k(m)\) be the Kruskal–Katona maximum number of \((k+1)\)-faces given \(m\) \(k\)-faces, via the canonical \(k\)-binomial expansion. A failure at index \(k\) requires \(u_{k+1}\ge K_k(u_k)+1\). Maclaurin's inequalities give
\[
u_{k+1}^kC_k^{k+1}\le C_{k+1}^ku_k^{k+1}.
\]

Define \(R_k(x)=\binom{x}{k+1}^{k}/\binom{x+1}{k}^{k+1}\), \(x>k\). Direct differentiation gives
\[
(\log R_k)'=k\sum_{j=0}^{k}\frac1{x-j}-(k+1)\sum_{j=-1}^{k-2}\frac1{x-j}>0.
\]
For the last inequality couple \(J=\lfloor(k+1)U\rfloor\) and \(L=\lfloor kU\rfloor-1\) for uniform \(U\in[0,1)\): \(J>L\) pointwise, so the first average of the increasing function \(j\mapsto1/(x-j)\) strictly exceeds the second. Thus \(R_k\) is strictly increasing.

Choose any integer \(r\ge d\) such that
\[
\binom r{k+1}^k C_k^{k+1}>C_{k+1}^k\binom{r+1}k^{k+1}.
\]
For \(u_k\ge\binom rk\), let \(a\ge r\) satisfy \(\binom ak\le u_k<\binom{a+1}k\). By Maclaurin, the displayed strict inequality and monotonicity of \(K_k\),
\[
u_{k+1}<\binom a{k+1}\le K_k(u_k).
\]
So any violation has \(C_k\le m=u_k<\binom rk\) and \(K_k(m)+1\le n=u_{k+1}\le \left\lfloor\big(C_{k+1}^k m^{k+1}/C_k^{k+1}\big)^{1/k}\right\rfloor\). `verify_through_12.py` generates **every** such integer pair using exact powers and integer roots.

Discrete concavity of \(f_j=\log v_j\) also gives the upper bound, for a prescribed violating pair \((u_k,u_{k+1})=(m,n)\):
\[
\begin{aligned}
f_j&\le (k+1-j)f_k-(k-j)f_{k+1} &&(j<k),\\
f_j&\le(j-k)f_{k+1}-(j-k-1)f_k&&(j>k+1).
\end{aligned}
\]
The code evaluates the resulting coefficient upper bounds as exact integer quotients, without logarithms or floating-point arithmetic.

## 2. Smyth's low-trace factor reduction

Theorem 1 of C. J. Smyth, *Totally positive algebraic integers of small trace*, **Annales de l'Institut Fourier** 34 (1984), pp. 1–28, gives \(\operatorname{Tr}(\alpha)>1.7719\deg(\alpha)\) for a totally positive algebraic integer \(\alpha\), unless its minimal polynomial belongs to the following five exceptions:
\[
\begin{gathered}
x-1,\quad x^2-3x+1,\quad x^3-5x^2+6x-1,\\
x^4-7x^3+13x^2-7x+1,\quad x^4-7x^3+14x^2-8x+1.
\end{gathered}
\]
**Primary source:** https://www.numdam.org/item/10.5802/aif.975.pdf (theorem on printed page 2).

Consequently, if the degree-\(d\) polynomial \(F\) has \(10000u_1\le17719d\), it has a factor whose coefficient sequence is one of
\[
(1,1),\ (1,3,1),\ (1,5,6,1),\ (1,7,13,7,1),\ (1,7,14,8,1).
\]
Every one satisfies all Kruskal–Katona inequalities (checked exactly by the script), so is an \(f\)-polynomial. A quotient by such a factor is again positive-integer-coefficient and real-rooted (Gauss's lemma plus negativity of remaining real roots). The product of \(f\)-polynomials is an \(f\)-polynomial (join of simplicial complexes). Thus **assuming the conjecture in lower degrees**, the conclusion holds in this case.

When \(u_d=1\), the reversed polynomial \(t^dF(1/t)\) also has positive integer coefficients, constant one and real negative zeros, with first coefficient \(u_{d-1}\). Applying Smyth to it eliminates \(10000u_{d-1}\le17719d\). Reversing any resulting exceptional factor gives the coefficient sequences
\[
(1,1),\ (1,3,1),\ (1,6,5,1),\ (1,7,13,7,1),\ (1,8,14,7,1),
\]
which again satisfy Kruskal–Katona. This is another valid inductive reduction.

## 3. Elementary inverse-trace obstruction when \(u_d=2\)

**Lemma.** If \(F(-1)\ne0\), then
\[
\frac{u_{d-1}}{u_d}+\frac32\log u_d>\frac{29}{20}d.
\]
Proof. Put \(h(x)=x-\frac34\log(x|x-1|)\), \(x>0\), \(x\ne1\). Its only stationary points are \((5\pm\sqrt{13})/4\). On either interval \((0,1)\) and \((1,\infty)\), \(h\) tends to infinity at the endpoints, and its stationary minimum exceeds \(29/20\). This last numerical-looking inequality has an **exact rational certificate** in `verify_through_12.py`: rational brackets on both stationary points and two Taylor-series bounds for exponentials.

Apply \(h\) to the reciprocal numbers \(\mu_i=1/\lambda_i\). Their sum is \(u_{d-1}/u_d\), their product \(1/u_d\), and \(\prod_i|1-\mu_i|=|F(-1)|/u_d\). Since \(F(-1)\) is a nonzero integer,
\[
\sum_i h(\mu_i)
=\frac{u_{d-1}}{u_d}+\frac32\log u_d-\frac34\log|F(-1)|
\le\frac{u_{d-1}}{u_d}+\frac32\log u_d,
\]
while the left side is strictly greater than \(29d/20\). QED.

For \(u_d=2\), use \(\log2<1\): if \(10u_{d-1}+30<29d\), the lemma is contradicted, so \(F(-1)=0\). This forces the factor \((1+t)\), which is already an \(f\)-polynomial. The verifier checks this sufficient exact **integer inequality** using the upper bound on \(u_{d-1}\); no floating-point logarithms are used.

## 4. Exhaustive proof certificate for remaining norm-one cases

After the above reductions, the code verifies that the last coefficient can never exceed 2 (in degrees at most 12). The \(u_d=2\) case is always eliminated by the lemma. Where \(u_d=1\) and Smyth's reciprocal reduction does not apply, there remain only **50 adjacent coefficient pairs** across all degrees 2–12: 2, 6, 13 and 29 in degrees 9, 10, 11 and 12 respectively.

For these cases, reverse \(F\) and write \(Q(t)=t^dF(1/t)=\sum_{j=0}^dq_jt^j\), with \(q_0=q_d=1\). In each case the violating pair fixes either \((q_1,q_2)=(n,m)\) or \((q_2,q_3)=(n,m)\); for the latter, the code enumerates every possible integer \(q_1\) from \(d\) to the exact tangent upper bound.

Starting with the fixed prefix, assign coefficients \(q_3,q_4,\ldots,q_{d-1}\) in order. Any positive-rooted polynomial must meet these **necessary** bounds:
\[
\begin{aligned}
q_j&\le\left\lfloor\frac{\binom dj q_2^{j-1}d^{j-2}}{\binom d2^{j-1}q_1^{j-2}}\right\rfloor,\\
q_j&\le\left\lfloor\frac{\binom dj\binom d{j-2}q_{j-1}^2}{\binom d{j-1}^2q_{j-2}}\right\rfloor,\\
\left(\frac{q_j}{\binom dj}\right)^{d-j+1}&\ge\left(\frac{q_{j-1}}{\binom d{j-1}}\right)^{d-j}.
\end{aligned}
\]
The first is a Newton tangent bound, the second local Newton log-concavity, and the third the concavity chord to \(q_d=1\). The third yields an exact **integer lower bound** via rational integer roots.

Let \(p_s=\sum_i\mu_i^s\) be the moments of the positive reciprocal roots. Each unshifted Hankel matrix \(H_r=(p_{i+j})\) and shifted matrix \(S_r=(p_{i+j+1})\) must be positive semidefinite. When \(j\) is even use \(H_{j/2+1}\), and when \(j\) is odd use \(S_{(j+1)/2}\); its determinant must be nonnegative. By Newton's identities, the determinant is affine in the newly assigned \(q_j\), even when a principal minor is zero. The verifier evaluates its constant and slope using **exact rational Gaussian elimination**, then excludes only coefficient values that make it negative.

Both implementations enumerate all remaining integers in the derived intervals. Neither needs sufficiency of the moment conditions: **zero surviving coefficient vectors under necessary conditions** suffices. An alternative implementation independently uses integer Bareiss determinants evaluated directly at interval endpoints/candidate values, rather than affine coefficient interpolation.

### Exact verification results

| degree | initial finite violating pairs | residual norm-one cases | exact recursion nodes | survivors |
|---:|---:|---:|---:|---:|
| 2 | 0 | 0 | 0 | 0 |
| 3 | 0 | 0 | 0 | 0 |
| 4 | 2 | 0 | 0 | 0 |
| 5 | 11 | 0 | 0 | 0 |
| 6 | 56 | 0 | 0 | 0 |
| 7 | 222 | 0 | 0 | 0 |
| 8 | 835 | 0 | 0 | 0 |
| 9 | 2,940 | 2 | 31 | 0 |
| 10 | 10,226 | 6 | 127 | 0 |
| 11 | 34,948 | 13 | 368 | 0 |
| 12 | 120,676 | 29 | 27,706 | 0 |

The independent direct-determinant implementation reproduced all residual-case conclusions and **the same node counts**, while an additional 10,000 exact rational-rounding checks and 1,018 independently constructed positive-real-rooted polynomial controls passed. The latter are adversarial sanity checks, **not** a substitute for the mathematical proof of the reductions.

## Reproduction

Run under Python 3.9 or newer with no third-party packages:

```bash
python verify_through_12.py
python independent_residual_audit.py
python adversarial_tests.py
```

The primary verifier writes `verification_results.json`; the alternative writes `independent_audit_results.json`. **All arithmetic used to decide inclusion or exclusion is exact.** Only console timing is external to the mathematical result.

## Remaining independent-review requirements

1. Have a mathematician check the proof of the finite cutoff and the direction of the Kruskal–Katona inequalities, including the binomial expansion implementation.
2. Check the use of Smyth's 1984 exception theorem, factor extraction and the join/reciprocal closure argument.
3. Verify the inverse-trace lemma with the attached exact rational certificate and its use for the norm-2 cases.
4. Audit the integer interval endpoints, DFS coverage, signed determinant pruning and exact moment matrix construction. Ideally independently formalise a minimal check in Lean/Isabelle or write a third verifier in another language.
5. Establish whether finite-degree results of this strength were already known and avoid asserting any new theorem/priority before a literature search and external review.

**Result interpretation:** The above constitutes a **candidate computer-assisted proof through degree 12**, not an externally established theorem and not a proof of the full (all-degree) Bell–Skandera conjecture.
