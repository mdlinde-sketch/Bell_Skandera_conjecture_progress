#!/usr/bin/env python3
"""Independently reconstruct exact Maclaurin/Kruskal-Katona violating adjacent-pair frontier.
No dependency on prior Bell-Skandera verifier. Does not certify factor reductions or DFS.
"""
from math import comb
import argparse,json

def kk(k,m):
    """Kruskal-Katona upper shadow count, exact binomial expansion."""
    remain=m; cap=None; ans=0
    for i in range(k,0,-1):
        lo=i-1; hi=i
        while comb(hi,i)<=remain and (cap is None or hi<cap):
            hi*=2
            if cap is not None and hi>=cap: hi=cap;break
        lo=i-1
        if cap is not None: hi=min(hi,cap)
        # Find greatest a with comb(a,i)<=remain and a<cap
        left=i-1;right=hi
        while left+1<right:
            mid=(left+right)//2
            if comb(mid,i)<=remain: left=mid
            else: right=mid
        a=left
        if a>=i:
            remain-=comb(a,i);ans+=comb(a,i+1)
        cap=a
    assert remain==0,(k,m,remain)
    return ans

def cutoff(d,k):
    C=comb(d,k);D=comb(d,k+1)
    r=d
    while comb(r,k+1)**k*C**(k+1)<=D**k*comb(r+1,k)**(k+1):r+=1
    return r

def scan(d,save=False):
    out=[]; counts={}; ranges={}
    for k in range(1,d):
        r=cutoff(d,k)
        lo=comb(d,k); hi=comb(r,k)
        count=0
        for m in range(lo,hi):
            kl=kk(k,m)+1
            # binary integer root bound
            target=comb(d,k+1)**k*m**(k+1)//comb(d,k)**(k+1)
            if kl**k>target:continue
            low=kl;high=max(low+1,2*low)
            while high**k<=target:high*=2
            while low+1<high:
                mid=(low+high)//2
                if mid**k<=target:low=mid
                else:high=mid
            count+=low-kl+1
            if save:
                out.extend((k,m,n) for n in range(kl,low+1))
        counts[k]=count;ranges[k]={'r':r,'m_start':lo,'m_stop_exclusive':hi}
    return {'degree':d,'total':sum(counts.values()),'counts':counts,'ranges':ranges,'pairs':out if save else None}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--degree',type=int,default=12);p.add_argument('--save',action='store_true');a=p.parse_args()
    x=scan(a.degree,a.save)
    print(json.dumps({k:v for k,v in x.items() if k!='pairs'},indent=2))
    if a.save:
        with open(f'/mnt/data/bs_audit_20261015/frontier_degree{a.degree}_20261016.json','w') as f:json.dump(x['pairs'],f)

def tangent_upper(d,k,m,n,j):
    if j==0:return 1
    if j==k:return m
    if j==k+1:return n
    Ck=comb(d,k); Ckp=comb(d,k+1)
    if j<k:
        a=k+1-j;b=k-j
        return comb(d,j)*m**a*Ckp**b//(Ck**a*n**b)
    a=j-k;b=j-k-1
    return comb(d,j)*n**a*Ck**b//(Ckp**a*m**b)

def classify(d):
    from collections import Counter
    cnt=Counter(); resid=[]; suspect=[]
    for k in range(1,d):
        r=cutoff(d,k); Ck=comb(d,k);D=comb(d,k+1)
        for m in range(Ck,comb(r,k)):
            kl=kk(k,m)+1
            target=D**k*m**(k+1)//Ck**(k+1)
            if kl**k>target:continue
            low=kl;high=max(low+1,2*low)
            while high**k<=target:high*=2
            while low+1<high:
                mid=(low+high)//2
                if mid**k<=target:low=mid
                else:high=mid
            for n in range(kl,low+1):
                cnt['raw']+=1
                u1=tangent_upper(d,k,m,n,1)
                if 10000*u1<=17719*d:cnt['smyth_original']+=1;continue
                ud=tangent_upper(d,k,m,n,d)
                if ud<1:cnt['impossible_ud']+=1;continue
                um=tangent_upper(d,k,m,n,d-1)
                if ud>=3:
                    cnt['ud_ge_3']+=1;suspect.append((k,m,n,ud,um));continue
                if 10000*um<=17719*d:
                    cnt['smyth_reverse_norm1']+=1
                else:
                    cnt['norm1_residual']+=1;resid.append((k,m,n,ud,um))
                if ud>=2:
                    if 10*um+30<29*d:cnt['norm2_inverse_elim']+=1
                    else:cnt['norm2_unresolved']+=1;suspect.append((k,m,n,ud,um))
    return dict(cnt),resid,suspect
