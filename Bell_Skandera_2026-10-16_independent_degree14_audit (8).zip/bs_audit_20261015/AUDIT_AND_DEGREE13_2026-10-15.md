# Bell–Skandera: adversarial review and finite-degree certificate, 15 October 2026

**Status: externally unreviewed candidate computer-assisted theorem for degrees <=13. Not a proof for all degrees.**

## Findings

1. Reproduced `verify_through_12.py` exactly. Degrees 2–12 passed. Reproduced its alternate Bareiss residual audit and 10,000 rounding/1,018 root-polynomial adversarial checks.
2. Read the original C. J. Smyth (1984), *Totally positive algebraic integers of small trace*, Ann. Inst. Fourier 34(3), theorem on printed page 2. Confirmed the bound `Tr(alpha)>1.7719 deg(alpha)` unless the minimal polynomial is one of exactly the five listed exceptions. https://www.numdam.org/item/10.5802/aif.975.pdf
3. The remaining finite search can use **only the unshifted Hankel determinants H3 (moments 0..4) and H4 (moments 0..6)**. Neither shifted matrices nor any coefficient beyond the sixth *reciprocal* coefficient is required: every candidate is eliminated by coefficient interval constraints, negative H3, or negative H4 before depth 7. This is a substantial simplification of the certificate, NOT a general theorem on arbitrary degrees.
4. Third independent verification in C++17/Boost cpp_int (`verify_low_moments.cpp`) uses direct permutation determinant expansion, unlike rational Gaussian and Bareiss in the first two scripts. All **131 residual cases across d=9,10,11,12,13** were eliminated; the Smyth-lower-trace restricted run traversed exactly **119,633** recursion nodes (total over all degrees). Exit code 0.
5. Original Python primary with just `LIMIT=13` completed and found **418,796** preliminary violating coefficient pairs in degree 13, of which **81** require residual checking after low-trace factor reductions. Its exact DFS traversed 483,173 nodes and found zero survivors.
6. The alternate direct-Bareiss Python verifier, extended to degree 13 and using only a logically justified lower bound on the reciprocal first coefficient, also eliminated the same 81 cases, with 113,055 degree-13 nodes and **119,633 total nodes through degree 13**, matching C++ independently.

## Tabulated results

| d | raw finite pairs | after trace/factor reductions | primary DFS nodes | survivors |
|--:|--:|--:|--:|--:|
| 2 | 0 | 0 | 0 | 0 |
| 3 | 0 | 0 | 0 | 0 |
| 4 | 2 | 0 | 0 | 0 |
| 5 | 11 | 0 | 0 | 0 |
| 6 | 56 | 0 | 0 | 0 |
| 7 | 222 | 0 | 0 | 0 |
| 8 | 835 | 0 | 0 | 0 |
| 9 | 2,940 | 2 | 31 | 0 |
| 10 | 10,226 | 6 | 127 | 0 |
| 11 | 34,948 | 13 | 368 | 0 |
| 12 | 120,676 | 29 | 27,706 | 0 |
| **13** | **418,796** | **81** | **483,173** | **0** |

## Mathematical justification to check independently

Let F(t)=prod_i(1+lambda_i t) have degree d, u0=1 and positive integral coefficients, all lambda_i>0. Maclaurin and KK imply that a counterexample exists only among finitely many adjacent coefficient pairs (m=u_k,n=u_{k+1}) with:

* `m >= binom(d,k)` and `m < binom(r_k,k)` for an exact integer cutoff r_k;
* `n > K_k(m)` and `n^k binom(d,k)^(k+1) <= binom(d,k+1)^k m^(k+1)`.

The exact monotonicity argument for the cutoff is in the primary proof note. Adjacent Newton log-concavity gives exact coefficient caps using tangent-line inequalities.

Smyth's theorem applies to *each irreducible factor* of the monic integral polynomial with roots lambda_i. If u1<=1.7719*d, at least one irreducible factor has small trace and hence belongs to Smyth's five exceptions. Its reciprocal t-factor is an f-polynomial; dividing it out and using the induction hypothesis suffices. If u_d=1, applying Smyth to the reciprocal polynomial reduces any case with u_(d-1)<=1.7719*d analogously. If u_d=2, the independent inverse-trace lemma in the source note shows that the remaining candidate pairs force F(-1)=0; then 1+t divides F and the induction hypothesis applies.

In residual *unit norm* cases, reversing F gives q0=q_d=1. The residual pairs fix (q1,q2) or (q2,q3). After the reverse Smyth reduction, necessarily q1>1.7719*d, so it is sound to limit the independent DFS to integers q1 >= floor(1.7719*d)+1. The first six coefficients are subjected to exact Newton tangent/local bounds, chord-to-(d,0) lower bounds, and only det(H3)>=0 at coefficient q4 and det(H4)>=0 at coefficient q6. Both matrices must be PSD if all roots are real and positive. All 131 residual cases fail before q7. **This yields a short finite certificate**, conditional on the explicitly stated mathematical reductions and exact code review.

## What has NOT been established

* No theorem in all degrees has been proved: the induction is only checked up to 13.
* There has not yet been independent specialist/referee review; all mathematical reasoning and code remain AI-produced.
* The third verifier receives the 131 residual pairs extracted from the primary program; it does *not* independently regenerate the entire finite frontier. The independent Python verifier also reads the primary residual list. An independent full-frontier generator is still desirable.
* The published result may be non-novel; a literature search found Mu–Welker (2026) and related counterexamples to a different recursive decomposition conjecture, not a matching proof through degree 13.
* Numerical checks of positive-root-generated polynomial examples do not establish exhaustive search correctness.

## Reproduction

From this archive directory:

```
python verify_through_13.py
python independent_residual_audit_13.py
g++ -O2 -std=c++17 verify_low_moments.cpp -o verify_low_moments
./verify_low_moments
```

The original proof note `PROOF_CANDIDATE_2026-10-15.md` still names degree 12; treat this addendum as the degree-13 update. The candidate theorem's proof structure is identical, replacing 12 with 13 and including the additional 81 exact residual cases.
