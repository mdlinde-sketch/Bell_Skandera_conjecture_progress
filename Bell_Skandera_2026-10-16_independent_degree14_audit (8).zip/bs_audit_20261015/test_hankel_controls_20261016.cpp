#define main unused_main
#include "independent_unitnorm_d14_20261016.cpp"
#undef main
#include <vector>
#include <cassert>
std::vector<U> mul(std::vector<U>a,std::vector<U>b){std::vector<U> c(a.size()+b.size()-1);for(size_t i=0;i<a.size();i++)for(size_t j=0;j<b.size();j++)c[i+j]+=a[i]*b[j];return c;}
int main(){init();std::vector<std::vector<U>> factors={{1,1},{1,3,1},{1,5,6,1},{1,7,13,7,1},{1,7,14,8,1}};
 std::vector<std::vector<int>> exps={{14,0,0,0,0},{0,7,0,0,0},{1,2,3,0,0},{0,0,2,2,0},{0,1,0,3,0},{0,1,0,0,3}};
 for(auto e:exps){std::vector<U> coeff={1};for(size_t i=0;i<e.size();i++)for(int j=0;j<e[i];j++)coeff=mul(coeff,factors[i]);if(coeff.size()!=15)continue;U q[15]={};for(int i=0;i<=14;i++)q[i]=coeff[i];assert(q[0]==1 && q[14]==1);auto h3=H3(14,q),h4=H4(14,q);std::cout<<"H3="<<h3<<" H4="<<h4<<"\n";assert(h3>=0 && h4>=0);}
}
