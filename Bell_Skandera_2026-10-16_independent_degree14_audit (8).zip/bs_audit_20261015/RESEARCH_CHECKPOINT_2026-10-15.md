# Bell–Skandera research checkpoint — 15 October 2026

**Status: candidate computer-assisted finite-degree proof, NOT reviewed or published theorem.**

Research has moved beyond the previous degree-12 partial brute-force checkpoints. A new mechanism combines: (i) exact finite KK/Maclaurin reduction; (ii) log-concavity tangent coefficient bounds; (iii) Smyth's 1984 theorem on totally positive algebraic integers and five exceptional factors, which all have simplicial f-polynomials, as do their reversals; (iv) an elementary logarithmic inverse-trace lemma forcing a factor `(1+t)` when a candidate has `u_d=2`; and (v) exhaustive exact moment-matrix pruning of the residual norm-one cases.

## Results reproduced

All degree-12 finite pairs: **120,676**.

- 119,906 pairs have the trace bound `u_1 <= floor(1.7719*12)` and reduce by Smyth's five factors to degrees below 12.
- 17 other pairs have an impossible upper bound `u_12=0`.
- 724 other pairs in the unit/reciprocal branch reduce by the same Smyth theorem applied to the reciprocal polynomial.
- The remaining 29 pairs allow `u_12=1` or `2`. For `u_12=2`, an exact inverse-trace inequality forces `(1+t)`; for `u_12=1`, the reverse-polynomial necessary-condition DFS explores 27,706 recursion nodes and produces zero survivors.

Inducting over degrees 2–12, the analogous residual counts are 2 cases/31 nodes for degree9, 6/127 for degree10, 13/368 for degree11, and 29/27,706 for degree12; all other smaller degrees have no residual. Two independent exact-arithmetic verifier implementations both complete with no surviving residual coefficient vector. Additional adversarial validation: 10,000 exact root-rounding checks, 1,018 constructed positive-rooted integer polynomials and 6,846 moment determinant controls passed.

**External theorem:** C. J. Smyth (1984), *Totally positive algebraic integers of small trace*, Theorem on printed page 2: https://www.numdam.org/item/10.5802/aif.975.pdf. This theorem is crucial and already known; no novelty claim is made for it.

## Reproduction and audit

The complete, still-unreviewed proof note is `PROOF_CANDIDATE_2026-10-15.md`. Run scripts `verify_through_12.py`, `independent_residual_audit.py` and `adversarial_tests.py` (standard Python 3 only) and inspect their generated JSON files. These are in the corresponding 15 October candidate-proof archive, but might not yet have been uploaded to GitHub. **Do not mistake this research checkpoint for independent mathematical confirmation.**

The original 15 October k5=10,323 and k6=2,001 preliminary computational states remain in the separate uncommitted archive. If switching back to the old brute-force path, do not silently overwrite or reset them. The new conditional-factoring route supersedes that approach for candidate proof purposes but must survive adversarial mathematical review first.

### Next action

Review the finite cutoff, signed determinant pruning and Hermite PSD necessity line by line; challenge the Smyth exceptional-factor/reciprocal closure; test a third independent verifier or Lean formalisation; establish novelty before journal submission. The conjecture in *all degrees* is still open.
